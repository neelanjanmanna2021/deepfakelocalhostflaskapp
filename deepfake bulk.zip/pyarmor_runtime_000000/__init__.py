# Pyarmor 8.5.11 (trial), 000000, 2024-10-24T14:44:36.814684
from .pyarmor_runtime import __pyarmor__
